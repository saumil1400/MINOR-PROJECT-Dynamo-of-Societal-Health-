from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('total/', views.total, name='total'),
    path('tech/', views.tech, name='tech'),
    path('remote/', views.remote, name='remote'),
    path('sleep/', views.sleep, name='sleep'),
    path('predict_population/', views.predict_population, name='predict_population'),
    
    path('predict_tech/', views.predict_tech, name='predict_tech'),
    path('predict_remote/', views.predict_remote, name='predict_remote'),  
    path('predict_sleep/', views.predict_sleep, name='predict_sleep'),  
        path('about/', views.about, name='about'),  
]
