from django.shortcuts import render
import pandas as pd
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from statsmodels.tsa.arima.model import ARIMA
import warnings
import numpy as np

df = pd.read_csv(r"C:\Users\SAUMIL GUPTA\Downloads\TOTAL_POPULATION.csv")
correct_column_name = df.columns[0]
train_df = df[(df[correct_column_name] >= 1950) & (df[correct_column_name] <= 2023)]
X_train = train_df[[correct_column_name]]
y_train = train_df.drop([correct_column_name], axis=1)
# POLYNOMIAL MODEL
poly = PolynomialFeatures(degree=2)
X_poly = poly.fit_transform(X_train)
model = LinearRegression()
model.fit(X_poly, y_train)

def predict_population(request):
    prediction, prediction_compare = None, None
    selected_year, compare_year = None, None
    display_option = 'numbers'
    view_option = 'tabular'

    if request.method == 'POST':
        selected_year = int(request.POST.get('year'))
        compare_year = int(request.POST.get('years'))
        display_option = request.POST.get('display_option', 'numbers')
        view_option = request.POST.get('view_option', 'tabular')

        def get_data_or_prediction(year):
            if 1950 <= year <= 2023:
                # RETURN ACTUAL DATA FROM CSV FILE
                actual_data = df[df[correct_column_name] == year].drop(correct_column_name, axis=1)
                return actual_data
            else:
                # PREDICT 
                future_year = pd.DataFrame({correct_column_name: [year]})
                future_year_poly = poly.transform(future_year)
                prediction_values = model.predict(future_year_poly)
                return pd.DataFrame(prediction_values, columns=df.columns[1:], index=[year])

        predicted_df = get_data_or_prediction(selected_year)
        predicted_df_compare = get_data_or_prediction(compare_year)

        if display_option == 'percentage':
            total_population = predicted_df.sum(axis=1).values[0]
            predicted_df = (predicted_df / total_population) * 100
            total_population_compare = predicted_df_compare.sum(axis=1).values[0]
            predicted_df_compare = (predicted_df_compare / total_population_compare) * 100
        elif display_option == 'numbers':
            # CONVERT TO CRORES
            predicted_df = predicted_df / 10000
            predicted_df_compare = predicted_df_compare / 10000

        # ROUNDING RESULT TO 2 DECIMAL PLACES
        predicted_df = predicted_df.round(3)
        predicted_df_compare = predicted_df_compare.round(3)

        # PREPARE DATA FOR RENDERING
        prediction = predicted_df.to_dict(orient="records")[0]
        prediction_compare = predicted_df_compare.to_dict(orient="records")[0]

    return render(request, 'total.html', {
        'prediction': prediction,
        'prediction_compare': prediction_compare,
        'selected_year': selected_year,
        'compare_year': compare_year,
        'display_option': display_option,
        'view_option': view_option
    })




# FOR TECH POPULATION
def helper(selected_year):
    future_years = pd.DataFrame({correct_column_name: [selected_year]})
    future_years_poly = poly.transform(future_years)
    predictions = model.predict(future_years_poly)
    predicted_df = pd.DataFrame(predictions, columns=df.columns[1:], index=[selected_year])
    predicted_df = predicted_df.astype(int)
    return predicted_df.to_dict(orient="records")[0]



df_tech_population = pd.read_csv(r"C:\Users\SAUMIL GUPTA\Downloads\TECH_POPULATION.csv")
warnings.filterwarnings("ignore")
arima_model = ARIMA(df_tech_population['Percentage'], order=(4, 1, 1))
arima_model_fit = arima_model.fit()

def predict_tech(request):
    prediction = None
    selected_year = None
    display_option = 'numbers'
    workforce=None
    if request.method == 'POST':
        selected_year = int(request.POST.get('year'))
        display_option = request.POST.get('display_option', 'numbers')
        forecast_steps = selected_year - 2023
        forecast = arima_model_fit.forecast(steps=forecast_steps)
        predicted_percentage = forecast.iloc[-1]  
        pop_prediction = helper(selected_year)  
        age_groups = ['20-24', '25-29', '30-34', '35-39', '40-44', '45-49', '50-54', '55-59']
        tech_population = sum(pop_prediction[group] for group in age_groups)


        if display_option == 'percentage':
            prediction = f"{predicted_percentage:.2f}%"
            tech_population=(tech_population*1000)/10000000
        
        else:
            tech_population_estimate = tech_population * (predicted_percentage / 100)
            prediction = f"{tech_population_estimate * 1000 / 10000000:.2f}"
            tech_population=(tech_population*1000)/10000000
            
    return render(request, 'tech.html', {
        'prediction': prediction,
        'selected_year': selected_year,
        'display_option': display_option,
        'workforce':tech_population
    })




#REMOTE
def helpers(selected_year):
    warnings.filterwarnings("ignore")
    arima_model = ARIMA(df_tech_population['Percentage'], order=(4, 1, 1))    
    arima_model_fit = arima_model.fit()
    forecast_steps = selected_year - 2023
    forecast = arima_model_fit.forecast(steps=forecast_steps)
    predicted_percentage = forecast.iloc[-1]  
    pop_prediction = helper(selected_year)  
    age_groups = ['20-24', '25-29', '30-34', '35-39', '40-44', '45-49', '50-54', '55-59']
    tech_population = sum(pop_prediction[group] for group in age_groups)
    tech_population_estimate = tech_population * (predicted_percentage / 100)*(1000/10000000)
    return tech_population_estimate  





dfs = pd.read_csv(r"C:\Users\SAUMIL GUPTA\Downloads\REMOTE_POPULATION.csv")
def predict_remote(request):
    prediction = None
    selected_year = None
    display_option = "numbers"  
    
    if request.method == 'POST':
        selected_year = int(request.POST.get('year'))
        display_option = request.POST.get('display_option')
        
        X = dfs[['Year']]
        y = dfs['Percentage']
        
        model = LinearRegression()
        model.fit(X, y)
        
        predicted_percentage = model.predict(np.array([[selected_year]]))[0]
        techs = helpers(selected_year)  
        
        if display_option == "percentage":
            prediction = f"{predicted_percentage:.2f}"
        else: 
            predicted_percentage = (predicted_percentage * techs) / 100
            prediction = f"{predicted_percentage:.2f}"

    return render(request, 'remote.html', {
        'prediction': prediction,
        'selected_year': selected_year,
        'display_option': display_option,
        'total': techs,
        'percentage_of_prediction' : float(prediction)  * 0.155 
    })









#MENTAL HEALTH
def predict_sleep(request):
    prediction = None
    selected_year = None
    display_option = "numbers"
    techs = None   
    
    if request.method == 'POST':
        selected_year = int(request.POST.get('year'))
        display_option = request.POST.get('display_option')
        
        X = dfs[['Year']]
        y = dfs['Percentage']
        
        model = LinearRegression()
        model.fit(X, y)
        
        predicted_percentage = model.predict(np.array([[selected_year]]))[0]
        techs = helpers(selected_year)  
        
        if display_option == "percentage":
            prediction = f"{predicted_percentage:.2f}"
        else: 
            predicted_percentage = (predicted_percentage * techs) / 100
            prediction = f"{predicted_percentage:.2f}"

    return render(request, 'sleep.html', {
        'prediction': prediction,
        'selected_year': selected_year,
        'display_option': display_option,
        'total': techs,
        'percentage_of_prediction': float(prediction) * 0.155 if prediction is not None else None, 
         'percentage_of_prediction2': float(prediction) * 0.025 if prediction is not None else None , 
          'percentage_of_prediction3': float(prediction) * 0.185 if prediction is not None else None ,
           'percentage_of_prediction4': float(prediction) * 0.095 if prediction is not None else None , 
            'percentage_of_prediction5': float(prediction) * 0.035 if prediction is not None else None  
    })


# Other view functions
def index(request):
    return render(request, 'index.html')

def total(request):
    return render(request, 'total.html')

def tech(request):
    return render(request, 'tech.html')

def remote(request):
    return render(request, 'remote.html')

def sleep(request):
    return render(request, 'sleep.html')

def about(request):
    return render(request, 'about.html')